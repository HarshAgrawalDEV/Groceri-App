import { View, Text } from 'react-native'
import React from 'react'

const Categories = () => {
    return (
        <View>
            <Text>Categories</Text>
        </View>
    )
}

export default Categories