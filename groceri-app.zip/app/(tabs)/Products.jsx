import { View, Text } from 'react-native'
import React from 'react'

const Products = () => {
    return (
        <View>
            <Text>Products</Text>
        </View>
    )
}

export default Products