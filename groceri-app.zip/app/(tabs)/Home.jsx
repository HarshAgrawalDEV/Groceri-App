import { View, Text, ScrollView } from 'react-native'
import React from 'react'
import Banner from '../../components/Banner'


import BannerCarousel from '../../components/carousel/BannerCarousel'
import BestProducts from '../../components/BestProducts'
import DiscountBanner from '../../components/DiscountBanner'
import CollectionsCarousel from '../../components/carousel/CollectionsCarousel'






const Home = () => {
    return (
        <ScrollView className=''>
            <Banner />

            <BannerCarousel />

            <BestProducts />

            <DiscountBanner />

            <CollectionsCarousel />


        </ScrollView>
    )
}

export default Home