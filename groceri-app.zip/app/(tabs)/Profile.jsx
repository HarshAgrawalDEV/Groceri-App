import { Text, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import * as SecureStore from 'expo-secure-store';
import { useNavigation } from 'expo-router';

const Profile = () => {

    const [token, setToken] = useState(null)

    const navigation = useNavigation()

    useEffect(() => {
        const isLoggedIn = async () => {
            const value = await SecureStore.getItemAsync('userToken')
            console.log(value);
            if (value) {
                setToken(value)
            }

        }
        isLoggedIn()
    }, [])

    if (!token) {
        navigation.navigate("Login")
    }


    return (
        <View>
            <Text>Profile</Text>
        </View>
    )
}

export default Profile

