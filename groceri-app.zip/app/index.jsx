import { View, Text, Pressable } from 'react-native'
import React from 'react'
import { Redirect, useNavigation } from 'expo-router'

const index = () => {
    const navigation = useNavigation()
    return (
        <Redirect href='Home' />


    )
}

export default index